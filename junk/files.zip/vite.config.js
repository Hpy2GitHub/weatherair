import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // base: '/your-repo-name/',  // ← uncomment + set this when deploying to GitHub Pages
})
