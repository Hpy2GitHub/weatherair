import { useState, useEffect } from 'react'
import './App.css'

// WMO weather interpretation codes → label + emoji
const WMO = {
  0:  { label: 'Clear Sky',          icon: '☀️' },
  1:  { label: 'Mainly Clear',       icon: '🌤️' },
  2:  { label: 'Partly Cloudy',      icon: '⛅' },
  3:  { label: 'Overcast',           icon: '☁️' },
  45: { label: 'Foggy',              icon: '🌫️' },
  48: { label: 'Icy Fog',            icon: '🌫️' },
  51: { label: 'Light Drizzle',      icon: '🌦️' },
  53: { label: 'Drizzle',            icon: '🌦️' },
  55: { label: 'Heavy Drizzle',      icon: '🌧️' },
  56: { label: 'Freezing Drizzle',   icon: '🌧️' },
  57: { label: 'Heavy Fr. Drizzle',  icon: '🌧️' },
  61: { label: 'Light Rain',         icon: '🌧️' },
  63: { label: 'Rain',               icon: '🌧️' },
  65: { label: 'Heavy Rain',         icon: '🌧️' },
  66: { label: 'Freezing Rain',      icon: '🌨️' },
  67: { label: 'Heavy Fr. Rain',     icon: '🌨️' },
  71: { label: 'Light Snow',         icon: '🌨️' },
  73: { label: 'Snow',               icon: '❄️' },
  75: { label: 'Heavy Snow',         icon: '❄️' },
  77: { label: 'Snow Grains',        icon: '🌨️' },
  80: { label: 'Light Showers',      icon: '🌦️' },
  81: { label: 'Showers',            icon: '🌧️' },
  82: { label: 'Heavy Showers',      icon: '⛈️' },
  85: { label: 'Snow Showers',       icon: '🌨️' },
  86: { label: 'Heavy Snow Showers', icon: '❄️' },
  95: { label: 'Thunderstorm',       icon: '⛈️' },
  96: { label: 'Thunderstorm',       icon: '⛈️' },
  99: { label: 'Thunderstorm',       icon: '⛈️' },
}

const getCondition = (code) => WMO[code] ?? { label: 'Unknown', icon: '🌡️' }

const WIND_DIRS = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
const windDir   = (deg) => WIND_DIRS[Math.round(deg / 45) % 8]

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

function fmtHour(d) {
  const h = d.getHours()
  if (h === 0)  return '12am'
  if (h === 12) return '12pm'
  return h < 12 ? `${h}am` : `${h - 12}pm`
}

// ─── Main App ────────────────────────────────────────────────────────────────

export default function App() {
  const [phase,    setPhase]    = useState('loading') // loading | error | ready
  const [weather,  setWeather]  = useState(null)
  const [location, setLocation] = useState(null)
  const [error,    setError]    = useState('')
  const [unit,     setUnit]     = useState('f')

  useEffect(() => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.')
      setPhase('error')
      return
    }

    navigator.geolocation.getCurrentPosition(
      async ({ coords: { latitude: lat, longitude: lon } }) => {
        try {
          const [weatherRes, geoRes] = await Promise.all([
            fetch(
              'https://api.open-meteo.com/v1/forecast' +
              `?latitude=${lat}&longitude=${lon}` +
              '&current=temperature_2m,relative_humidity_2m,apparent_temperature,' +
              'precipitation,weather_code,wind_speed_10m,wind_direction_10m,is_day' +
              '&hourly=temperature_2m,weather_code,precipitation_probability' +
              '&daily=weather_code,temperature_2m_max,temperature_2m_min,' +
              'precipitation_probability_max,sunrise,sunset' +
              '&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch' +
              '&timezone=auto&forecast_days=7'
            ),
            fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`),
          ])

          if (!weatherRes.ok) throw new Error('Weather API error')

          const [weatherData, geoData] = await Promise.all([
            weatherRes.json(),
            geoRes.json(),
          ])

          setWeather(weatherData)
          setLocation({
            city:
              geoData.address?.city    ||
              geoData.address?.town    ||
              geoData.address?.village ||
              geoData.address?.county  ||
              'Your Location',
            region:  geoData.address?.state_code || geoData.address?.state || '',
            country: geoData.address?.country_code?.toUpperCase() || '',
          })
          setPhase('ready')
        } catch {
          setError('Could not load weather data. Please try again.')
          setPhase('error')
        }
      },
      () => {
        setError('Location access denied. Please allow location in your browser settings.')
        setPhase('error')
      },
      { timeout: 10_000 }
    )
  }, [])

  const toC     = (f)       => Math.round((f - 32) * 5 / 9)
  const fmt     = (f)       => unit === 'f' ? `${Math.round(f)}°` : `${toC(f)}°`
  const fmtTime = (d)       => d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })

  if (phase === 'loading') return <Loader />
  if (phase === 'error')   return <ErrorView message={error} />

  const { current, daily, hourly } = weather
  const cond = getCondition(current.weather_code)

  // Build next-24h slice
  const nowMs = Date.now()
  const hIdx  = hourly.time.findIndex((t) => new Date(t).getTime() >= nowMs)
  const next24 = Array.from({ length: 24 }, (_, i) => ({
    time:   hourly.time[hIdx + i],
    temp:   hourly.temperature_2m[hIdx + i],
    code:   hourly.weather_code[hIdx + i],
    precip: hourly.precipitation_probability[hIdx + i],
    label:  i === 0 ? 'Now' : fmtHour(new Date(hourly.time[hIdx + i])),
  }))

  return (
    <div className="app">

      {/* ── Header ─────────────────────────────────── */}
      <header className="header fade-in">
        <div>
          <h1 className="city">{location.city}</h1>
          <p className="region">
            {[location.region, location.country].filter(Boolean).join(' · ')}
          </p>
        </div>
        <div className="unit-toggle">
          <button className={unit === 'f' ? 'active' : ''} onClick={() => setUnit('f')}>°F</button>
          <button className={unit === 'c' ? 'active' : ''} onClick={() => setUnit('c')}>°C</button>
        </div>
      </header>

      {/* ── Hero temp ──────────────────────────────── */}
      <section className="hero fade-in-2">
        <div className="hero-icon">{cond.icon}</div>
        <div className="hero-temp">{fmt(current.temperature_2m)}</div>
        <div className="hero-cond">{cond.label}</div>
        <div className="hero-feels">Feels like {fmt(current.apparent_temperature)}</div>
      </section>

      {/* ── Stats card ─────────────────────────────── */}
      <section className="card fade-in-3">
        <Stat label="Humidity"         value={`${current.relative_humidity_2m}%`} />
        <Stat label="Wind"             value={`${Math.round(current.wind_speed_10m)} mph ${windDir(current.wind_direction_10m)}`} />
        <Stat label="Precipitation"    value={`${current.precipitation.toFixed(2)}"`} />
        <Stat label="Sunrise / Sunset" value={`${fmtTime(new Date(daily.sunrise[0]))} / ${fmtTime(new Date(daily.sunset[0]))}`} last />
      </section>

      {/* ── Hourly scroll ──────────────────────────── */}
      <section className="fade-in-4">
        <p className="section-label">Next 24 Hours</p>
        <div className="hourly-scroll">
          {next24.map((h) => (
            <div key={h.time} className="hour-card">
              <span className="hour-time">{h.label}</span>
              <span className="hour-icon">{getCondition(h.code).icon}</span>
              <span className="hour-temp">{fmt(h.temp)}</span>
              {h.precip > 0 && <span className="hour-precip">{h.precip}%</span>}
            </div>
          ))}
        </div>
      </section>

      {/* ── 7-day forecast ─────────────────────────── */}
      <section className="card fade-in-4">
        <p className="section-label">7-Day Forecast</p>
        {daily.time.map((dateStr, i) => {
          const d     = new Date(dateStr)
          const label = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : DAYS[d.getDay()]
          const dc    = getCondition(daily.weather_code[i])
          const pct   = daily.precipitation_probability_max[i]
          const last  = i === daily.time.length - 1
          return (
            <div key={dateStr} className={`day-row${last ? ' last' : ''}`}>
              <span className={`day-name${i === 0 ? ' today' : ''}`}>{label}</span>
              <span className="day-icon">{dc.icon}</span>
              <div className="precip-bar" title={`${pct}% chance of rain`}>
                <div className="precip-fill" style={{ width: `${pct}%` }} />
              </div>
              <div className="day-range">
                <span className="day-low">{fmt(daily.temperature_2m_min[i])}</span>
                <span className="day-high">{fmt(daily.temperature_2m_max[i])}</span>
              </div>
            </div>
          )
        })}
      </section>

      <p className="footer">Open-Meteo · No ads · No tracking</p>
    </div>
  )
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function Stat({ label, value, last }) {
  return (
    <div className={`stat-row${last ? ' last' : ''}`}>
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value}</span>
    </div>
  )
}

function Loader() {
  return (
    <div className="screen-center">
      <div className="spinner">🌍</div>
      <p className="loader-text">Locating…</p>
    </div>
  )
}

function ErrorView({ message }) {
  return (
    <div className="screen-center">
      <p className="error-text">{message}</p>
    </div>
  )
}
