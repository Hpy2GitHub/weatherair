#!/usr/bin/env python3
"""
mk-react-archive.py
Creates a project-contents.txt by calling util/concat.sh,
then packages it with missing files/folders into a timestamped zip.

Creates ./archive/archive-YYYY-MM-DD-HH-MM.zip containing:
    project-contents.txt
    public/
    .gitignore
    .git/config
    package.json / package-lock.json
"""

import os
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path

# ── Configuration ───────────────────────────────────────────────────────────

PROJECT_ROOT = Path(".") # be at the top of the react project
DOWNLOADS_DIR = Path("/mnt/c/Users/rho/Downloads")  
CONCAT_SCRIPT = PROJECT_ROOT / "util" / "concat.sh"
CONTENTS_FILE = DOWNLOADS_DIR / "project-contents.txt"
ARCHIVE_DIR = Path("./archive")
GIT_FILES = [".gitignore", ".git/config"]
PUBLIC_DIR = "public"
PACKAGE_FILES = ["package.json", "package-lock.json"]  # add yarn.lock if used

# Extra files/folders to include beyond project-contents.txt
EXTRA_ITEMS = [
    PUBLIC_DIR,
    *GIT_FILES,
    *PACKAGE_FILES,
]

# ── Step 1: Run concat.sh ───────────────────────────────────────────────────

def run_concat():
    """Execute util/concat.sh to generate project-contents.txt"""
    if not CONCAT_SCRIPT.exists():
        print(f"❌ concat.sh not found at {CONCAT_SCRIPT}")
        return False
    
    print(f"📄 Running {CONCAT_SCRIPT} ...")
    result = subprocess.run(
        ["bash", str(CONCAT_SCRIPT)],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        print(f"❌ concat.sh failed:\n{result.stderr}")
        return False
    
    print(f"✅ project-contents.txt created")
    return True

# ── Step 2: Create archive ──────────────────────────────────────────────────

def create_archive():
    """Package contents file + extra items into a timestamped zip"""
    
    # Build timestamped archive path
    timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M")
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    archive_path = ARCHIVE_DIR / f"archive-{timestamp}.zip"
    
    print(f"\n📦 Creating {archive_path} ...")
    
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        
        # 1. Add project-contents.txt at the root of the zip
        if CONTENTS_FILE.exists():
            zf.write(CONTENTS_FILE, "project-contents.txt")
            print(f"  + project-contents.txt")
        else:
            print(f"  ⚠️  {CONTENTS_FILE} not found — skipping")
        
        # 2. Add extra items
        for item in EXTRA_ITEMS:
            full_path = PROJECT_ROOT / item
            if full_path.exists():
                if full_path.is_dir():
                    for file in full_path.rglob("*"):
                        if file.is_file():
                            arcname = str(file.relative_to(PROJECT_ROOT))
                            zf.write(file, arcname)
                    print(f"  + {item}/  ({sum(1 for _ in full_path.rglob('*') if _.is_file())} files)")
                else:
                    zf.write(full_path, item)
                    print(f"  + {item}")
            else:
                print(f"  ⚠️  {item} not found — skipping")
    
    # ── Summary ─────────────────────────────────────────────────────────────
    size_kb = archive_path.stat().st_size / 1024
    print(f"\n✅ Archive created: {archive_path} ({size_kb:.1f} KB)")
    print(f"   Contents: project-contents.txt + {len(EXTRA_ITEMS)} extra items")
    return archive_path

# ── Run ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.chdir(Path(__file__).parent)  # ensure archive/ goes next to this script
    
    if run_concat():
        create_archive()
    else:
        print("\n❌ Aborted — concat.sh failed")
