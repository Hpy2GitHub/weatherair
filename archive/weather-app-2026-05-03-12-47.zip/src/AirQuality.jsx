import { useState, useEffect } from 'react'

// ─── AQI scale ────────────────────────────────────────────────────────────────

const AQI_LEVELS = [
  { max: 50,   label: 'Good',                      color: '#4ade80' },
  { max: 100,  label: 'Moderate',                  color: '#facc15' },
  { max: 150,  label: 'Unhealthy for Sensitive',   color: '#fb923c' },
  { max: 200,  label: 'Unhealthy',                 color: '#f87171' },
  { max: 300,  label: 'Very Unhealthy',            color: '#c084fc' },
  { max: Infinity, label: 'Hazardous',             color: '#9f1239' },
]

const getAqiMeta = (val) => AQI_LEVELS.find((l) => val <= l.max) ?? AQI_LEVELS.at(-1)

// ─── SVG helpers (matching SkyEvents) ────────────────────────────────────────

const CX = 110, CY = 98, R = 80

function polar(angleDeg) {
  const rad = (angleDeg * Math.PI) / 180
  return { x: CX + R * Math.cos(rad), y: CY - R * Math.sin(rad) }
}

function arcD(startDeg, endDeg) {
  const s = polar(startDeg)
  const e = polar(endDeg)
  const large = Math.abs(startDeg - endDeg) > 180 ? 1 : 0
  return `M ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${R} ${R} 0 ${large} 0 ${e.x.toFixed(2)} ${e.y.toFixed(2)}`
}

const GAUGE_MAX = 500

// Map AQI value to degrees on arc (180° left = 0, 0° right = 500)
function aqiToDeg(aqi) {
  const clamped = Math.max(0, Math.min(aqi, GAUGE_MAX))
  return 180 - (clamped / GAUGE_MAX) * 180
}

// ─── Zone segments ───────────────────────────────────────────────────────────

const SEGMENTS = [
  { from: 0,   to: 50,   color: '#4ade80' },  // Green  – Good
  { from: 51,  to: 100,  color: '#facc15' },  // Yellow – Moderate
  { from: 101, to: 150,  color: '#fb923c' },  // Orange – USG
  { from: 151, to: 200,  color: '#f87171' },  // Red    – Unhealthy
  { from: 201, to: 300,  color: '#c084fc' },  // Purple – Very Unhealthy
  { from: 301, to: 500,  color: '#9f1239' },  // Maroon – Hazardous
]

// ─── Pollutant components ─────────────────────────────────────────────────────

const COMPONENTS = [
  { key: 'us_aqi_pm2_5',            label: 'PM2.5' },
  { key: 'us_aqi_pm10',             label: 'PM10'  },
  { key: 'us_aqi_ozone',            label: 'Ozone' },
  { key: 'us_aqi_nitrogen_dioxide', label: 'NO₂'   },
  { key: 'us_aqi_sulphur_dioxide',  label: 'SO₂'   },
  { key: 'us_aqi_carbon_monoxide',  label: 'CO'    },
]

// ─── Pollen ───────────────────────────────────────────────────────────────────

const POLLEN_TYPES = [
  { key: 'alder_pollen',   label: 'Alder',   thresholds: [15, 75,  300] },
  { key: 'birch_pollen',   label: 'Birch',   thresholds: [15, 75,  300] },
  { key: 'grass_pollen',   label: 'Grass',   thresholds: [10, 50,  200] },
  { key: 'mugwort_pollen', label: 'Mugwort', thresholds: [10, 50,  200] },
  { key: 'olive_pollen',   label: 'Olive',   thresholds: [15, 75,  300] },
  { key: 'ragweed_pollen', label: 'Ragweed', thresholds: [10, 50,  200] },
]

const POLLEN_LABELS = ['None', 'Low', 'Moderate', 'High', 'Very High']
const POLLEN_COLORS = ['#334155', '#4ade80', '#facc15', '#fb923c', '#f87171']

function pollenLevel(val, [modT, highT, vhighT]) {
  if (!val || val <= 0) return 0
  if (val < modT)   return 1
  if (val < highT)  return 2
  if (val < vhighT) return 3
  return 4
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function AirQuality({ lat, lon }) {
  const [data,  setData]  = useState(null)
  const [error, setError] = useState(false)

  useEffect(() => {
    if (lat == null || lon == null) return

    const fields = [
      'us_aqi',
      ...COMPONENTS.map((c) => c.key),
      ...POLLEN_TYPES.map((p) => p.key),
    ].join(',')

    fetch(
      'https://air-quality-api.open-meteo.com/v1/air-quality' +
      `?latitude=${lat}&longitude=${lon}` +
      `&current=${fields}` +
      '&domains=cams_global'
    )
      .then((r) => { if (!r.ok) throw new Error(); return r.json() })
      .then((json) => setData(json.current))
      .catch(() => setError(true))
  }, [lat, lon])

  if (error || !data) return null

  // ── AQI ──
  const aqi     = Math.round(data.us_aqi ?? 0)
  const aqiMeta = getAqiMeta(aqi)

  // ── Components — filter out zeros, sort highest first ──
  const components = COMPONENTS
    .map((c) => ({ ...c, value: Math.round(data[c.key] ?? 0) }))
    .filter((c) => c.value > 0)
    .sort((a, b) => b.value - a.value)

  const primary = components[0] ?? null

  // ── Position dot ──
  const aqiDeg = aqiToDeg(aqi)
  const aqiPt  = polar(aqiDeg)

  // ── Pollen ──
  const pollens = POLLEN_TYPES
    .map((p) => ({ ...p, value: data[p.key] ?? 0, level: pollenLevel(data[p.key], p.thresholds) }))
    .filter((p) => p.value > 0)

  const worstPollen = pollens.length
    ? pollens.reduce((a, b) => (b.level > a.level ? b : a))
    : null

  return (
    <section className="aq-card card fade-in-4">

      {/* ── Gauge ──────────────────────────────────── */}
      <p className="section-label">Air Quality</p>

      <svg viewBox="0 0 220 120" className="aq-gauge"
        aria-label={`US AQI ${aqi} — ${aqiMeta.label}`}>

        {/* Horizon line & Hemisphere */}
        <line x1={CX - R - 8} y1={CY} x2={CX + R + 8} y2={CY}
          stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
        <path d={arcD(0, 180)} fill="rgba(0,0,0,0.18)" />

        {/* Full Track arc */}
        <path className="aq-track-bg"
          d={arcD(180, 0)} fill="none"
          strokeWidth="12" strokeLinecap="butt" />

        {/* Zone segments */}
        {SEGMENTS.map((s) => {
          const startDeg = aqiToDeg(s.to)
          const endDeg   = aqiToDeg(s.from)
          return (
            <path key={s.from}
              className="aq-zone-seg"
              d={arcD(startDeg, endDeg)}
              fill="none"
              stroke={s.color}
              strokeWidth="12"
              strokeLinecap="butt"
            />
          )
        })}

        {/* Current position marker */}
        <circle className="aq-marker-glow"
          cx={aqiPt.x} cy={aqiPt.y} r={10}
          fill={aqiMeta.color} />
        <circle className="aq-marker-dot"
          cx={aqiPt.x} cy={aqiPt.y} r={6}
          fill={aqiMeta.color} />

        {/* AQI value above the dot */}
        <text className="aq-value-text"
          x={aqiPt.x} y={aqiPt.y - 16}
          textAnchor="middle"
          fill={aqiMeta.color}>
          {aqi}
        </text>

        {/* Scale labels */}
        <circle className="aq-scale-dot" cx={polar(180).x} cy={CY} r={3} />
        <circle className="aq-scale-dot" cx={polar(0).x} cy={CY} r={3} />
        <text className="aq-scale-label" x={polar(180).x - 2} y={CY + 14} textAnchor="middle">0</text>
        <text className="aq-scale-label" x={polar(0).x + 2} y={CY + 14} textAnchor="middle">500</text>

        {/* Label under arc */}
        <text className="aq-label-text"
          x={CX} y={CY + 14}
          textAnchor="middle"
          fill={aqiMeta.color}>
          {aqiMeta.label.toUpperCase()}
        </text>
      </svg>

      {/* ── Pollutant bars ─────────────────────────── */}
      {components.length > 0 && (
        <div className="aq-components">
          {primary && (
            <p className="aq-driver">
              Primary: <span style={{ color: aqiMeta.color }}>{primary.label}</span>
            </p>
          )}
          <div className="aq-comp-grid">
            {components.map((c) => {
              const meta = getAqiMeta(c.value)
              const pct  = Math.min(c.value / GAUGE_MAX * 100, 100)
              return (
                <div key={c.key} className="aq-comp-row">
                  <span className="aq-comp-label">{c.label}</span>
                  <div className="aq-comp-track">
                    <div className="aq-comp-fill"
                      style={{ width: `${pct}%`, background: meta.color }} />
                  </div>
                  <span className="aq-comp-val" style={{ color: meta.color }}>{c.value}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── Pollen ─────────────────────────────────── */}
      {pollens.length > 0 && (
        <div className="aq-pollen">
          <p className="section-label">Pollen</p>

          {worstPollen && worstPollen.level >= 2 && (
            <p className="aq-alert" style={{ color: POLLEN_COLORS[worstPollen.level] }}>
              {worstPollen.label} pollen is {POLLEN_LABELS[worstPollen.level].toLowerCase()} right now
            </p>
          )}

          <div className="pollen-grid">
            {pollens.map((p) => (
              <div key={p.key} className="pollen-item">
                <div className="pollen-bars">
                  {[1, 2, 3, 4].map((tier) => (
                    <div key={tier} className="pollen-bar-seg"
                      style={{ background: p.level >= tier ? POLLEN_COLORS[tier] : 'rgba(255,255,255,0.07)' }} />
                  ))}
                </div>
                <span className="pollen-name">{p.label}</span>
                <span className="pollen-level" style={{ color: POLLEN_COLORS[p.level] }}>
                  {POLLEN_LABELS[p.level]}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {pollens.length === 0 && (
        <p className="aq-no-pollen">No active pollen detected</p>
      )}

    </section>
  )
}
