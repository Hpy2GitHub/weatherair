// MoonTable.jsx
import React, { useState, useEffect } from 'react';
import SunCalc from 'suncalc';
import MoonPhaseIcon from './MoonPhaseIcon';
import './design-system.css';

const getMoonPhaseName = (phase) => {
  if (phase < 0.0625) return "New Moon";
  if (phase < 0.1875) return "Waxing Crescent";
  if (phase < 0.3125) return "First Quarter";
  if (phase < 0.4375) return "Waxing Gibbous";
  if (phase < 0.5625) return "Full Moon";
  if (phase < 0.6875) return "Waning Gibbous";
  if (phase < 0.8125) return "Last Quarter";
  if (phase < 0.9375) return "Waning Crescent";
  return "New Moon";
};

const MoonTable = ({ lat, lon }) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const latitude  = parseFloat(lat);
    const longitude = parseFloat(lon);

    if (isNaN(latitude) || isNaN(longitude)) {
      setError("Invalid location coordinates.");
      setLoading(false);
      return;
    }

    try {
      const daily = [];
      const now   = new Date();

      for (let i = 0; i < 7; i++) {
        const date = new Date(now);
        date.setDate(date.getDate() + i);

        const moonTimes        = SunCalc.getMoonTimes(date, latitude, longitude);
        const moonIllumination = SunCalc.getMoonIllumination(date);

        daily.push({
          date:           date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          dayName:        i === 0 ? "Today" : date.toLocaleDateString('en-US', { weekday: 'long' }),
          moonrise:       moonTimes.rise
            ? moonTimes.rise.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })
            : "—",
          moonset:        moonTimes.set
            ? moonTimes.set.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })
            : "—",
          moonPhase:      getMoonPhaseName(moonIllumination.phase),
          moonPhaseValue: moonIllumination.phase,
        });
      }

      setData({ moonrise: daily[0].moonrise, moonset: daily[0].moonset, daily });
    } catch (err) {
      console.error(err);
      setError("Could not calculate moon data.");
    } finally {
      setLoading(false);
    }
  }, [lat, lon]);

  if (loading) return (
    <div className="screen-center">
      <div className="spinner">🌙</div>
      <div className="loader-text">Calculating...</div>
    </div>
  );

  if (error) return (
    <div className="card card--centered">
      <div className="card__error-icon">🌑</div>
      <div className="error-text">{error}</div>
    </div>
  );

  return (
    <div className="moon-screen">

      {/* Header */}
      <div className="moon-screen-header">
        <button onClick={() => window.history.back()} className="moon-back-btn">←</button>
        <h1 className="city">Sun &amp; moon</h1>
      </div>

      {/* Hero card — today's moonrise/set + 3-day phase preview */}
      <div className="card">
        <div className="section-label">MOON</div>

        <div className="moon-hero-times">
          <div>
            <div className="moon-hero-label">Moonrise</div>
            <div className="moon-hero-value">{data.moonrise}</div>
          </div>
          <div>
            <div className="moon-hero-label">Moonset</div>
            <div className="moon-hero-value">{data.moonset}</div>
          </div>
        </div>

        <div className="moon-preview">
          {data.daily.slice(0, 3).map((day, i) => (
            <div key={i} className="moon-preview-day">
              <div className={`moon-preview-label${i === 0 ? ' moon-preview-label--today' : ''}`}>
                {day.dayName}
              </div>
              <MoonPhaseIcon phase={day.moonPhaseValue} size={46} />
              <div className="moon-preview-phase">{day.moonPhase}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 7-day list */}
      <div className="stack" style={{ marginTop: 'var(--sp-5)' }}>
        {data.daily.map((day, index) => (
          <div key={index} className="card">
            <div className="row">

              <div className="moon-row-name">
                <div className="moon-row-name__day">{day.dayName}</div>
                <div className="moon-row-name__date">{day.date}</div>
              </div>

              <div className="moon-row-times">
                <div>
                  <div className="moon-row-label">Rise</div>
                  <div className="moon-row-value">{day.moonrise}</div>
                </div>
                <div>
                  <div className="moon-row-label">Set</div>
                  <div className="moon-row-value">{day.moonset}</div>
                </div>
              </div>

              <div className="moon-plus-label">
                <MoonPhaseIcon phase={day.moonPhaseValue} size={36} />
                <div className="moon-row-phase">{day.moonPhase}</div>
              </div>

            </div>
          </div>
        ))}
      </div>

    </div>
  );
};

export default MoonTable;
